import java.util.Scanner;

/**
 * Test
 */
public class Test {

    
public static Liste creationListe(Liste L) {

    
    Scanner sc = new Scanner(System.in);
    int n;
    do{
    System.out.println("Le nombre des Elements : ");
    n=sc.nextInt();
    }while(n<0);
   

   for (int i = 0; i < n; i++) {
    System.out.println(" Element  nombre " + i + " : ");
    Element e = new Element(sc.nextInt()); 
    L=L.inserer(L, L, e);

    }
    
    return L;
}

public static void affichageListe(Liste L) {

    if (L.Suivant(L)!=null) {
        System.out.print(L.acces(L, L).getId() + "-->"); 
        affichageListe(L.Suivant(L));
    }else System.out.print("/");

    
}

public static void main(String[] args) {
    System.out.println(" la liste 1 : ");
    Liste liste1 = Liste.liste_vide();
    liste1=creationListe(liste1);
    if(liste1.est_vide(liste1)) System.out.println("la liste est vide ");
    else{System.out.println(" les element de la list sont : ");
    affichageListe(liste1);
}

    //!partie 2
    System.out.println(" \npartie 2 : ");
    System.out.println(" le Element e1 : ");
    Scanner sc = new Scanner(System.in);
    Element e1 = new Element(sc.nextInt());
    if(liste1.est_vide(liste1)) System.out.println("la liste est vide  la rechereche est impossible ");
    else{
        Liste R = liste1.recherche(liste1, e1);
        if(R.est_vide(R)) System.out.println(" le element e1 n'existe pas dans la liste ");
        else System.out.println(" le element e1 existe dans la liste "); 
    }
    //! partie 3
    System.out.println("partie 3 :");
    System.out.println(" la liste 2 : ");
    Liste liste2 = Liste.liste_vide();
    liste2=creationListe(liste2);
    if(liste2.est_vide(liste2)) System.out.println("la liste est vide ");
    else{System.out.println(" les element de la list sont : ");
    affichageListe(liste2);}
    System.out.println();

    if(liste1.est_vide(liste1) && liste2.est_vide(liste2)) System.out.println("les deux listes sont vide ");
    else{
            if(liste1.est_vide(liste1)) {
                System.out.println(" la defference entre L1 et L2 est liste 1 :");
                affichageListe(liste2);
    }
        else if(liste1.est_vide(liste2)) {
                System.out.println(" la defference entre L1 et L2 est liste 2");
                affichageListe(liste2);
    }else {

        System.out.println(" la defference entre L1 et L2 est ");
        affichageListe( liste1.difference(liste1, liste2));
    }}
}
}