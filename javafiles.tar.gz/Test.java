import java.util.Scanner;

/**
 * Test
 */
public class Test {

    
public static Liste creationListe(Liste L) {

    
    Scanner sc = new Scanner(System.in);
    int n;
    do{
    System.out.println("Le nombre des Etudiants : ");
    n=sc.nextInt();
    }while(n<0);
   

   for (int i = 0; i < n; i++) {
    System.out.println(" Etudiant  nombre " + i + " : ");
    Etudiant e = new Etudiant();
    e.LireInfo();
    L=L.inserer(L, L, e);

    }
    
    return L;
}

public static void affichageListe(Liste L) {

    if (L.Suivant(L)!=null) {
        System.out.println(L.acces(L, L)); 
        affichageListe(L.Suivant(L));
    }else System.out.print("/");

    
}

public static void main(String[] args) {




    System.out.println(" la liste des etudiants : ");
        Liste liste1 = Liste.liste_vide();
        liste1=creationListe(liste1);
        Etudiant e1 = new Etudiant(0, "me ", "zoubir", "39", "0");
        Etudiant e2 = new Etudiant(0, "mm2 ", "zoubir", "39", "0");
        Etudiant e3 = new Etudiant(0, "me3 ", "zoubir", "39", "0");
        liste1=liste1.inscription(e3);
        liste1=liste1.inscription(e2);
        liste1=liste1.inscription(e1);
        liste1=liste1.inscription(e3);
        liste1=liste1.inscription(e2);
        liste1=liste1.inscription(e3);
        liste1=liste1.inscription(e1);
        liste1=liste1.inscription(e3);

        if(liste1.est_vide(liste1)) System.out.println("la liste est vide ");
         else{System.out.println(" les etudiants sont : ");
        affichageListe(liste1.Tri(liste1));

     }
     
     

    
}}