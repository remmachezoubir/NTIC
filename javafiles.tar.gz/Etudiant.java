import java.util.Scanner;

/**
 * Etudiant
 */
public class Etudiant {

    int ncarte;
    String nom ,prenom , date_naiss, adresse;
    public Etudiant() {
    }
    public Etudiant(int ncarte, String nom, String prenom, String date_naiss, String adresse) {
        this.ncarte = ncarte;
        this.nom = nom;
        this.prenom = prenom;
        this.date_naiss = date_naiss;
        this.adresse = adresse;
    }
    public int getNcarte() {
        return ncarte;
    }
    public String getNom() {
        return nom;
    }
    public String getPrenom() {
        return prenom;
    }
    public String getDate_naiss() {
        return date_naiss;
    }
    public String getAdresse() {
        return adresse;
    }
    

    public void LireInfo() {
        Scanner sc = new Scanner(System.in);
        System.out.println(" le n° de la carte : ");
        ncarte=sc.nextInt();
        System.out.println(" le nom : ");
        nom=sc.next();
        System.out.println(" le prenom : ");
        prenom=sc.next();
        System.out.println(" le date de naiss : ");
        date_naiss=sc.next();
        System.out.println(" l` adresse : ");
        adresse=sc.next();

    }

    @Override
    public String toString() {
        
        return "le etudiant : " + prenom +" , le nom : " + nom + " , le ncart : " + ncarte + " , date de naiss : "
        + date_naiss + " , l` adresse : " + adresse + " .";
    }

}