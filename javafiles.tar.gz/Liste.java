
/**
 * Liste
 */
public class Liste {

    private Etudiant info;
    private Liste Suiv;



public static Liste liste_vide() {
    return new Liste();
}
public Liste inserer(Liste L , Liste p , Etudiant e) {
    
    Liste T=new Liste();
    T.info = e;
    T.Suiv =p;
    if (p==L)
     L=T;
    else {
        Liste R =L;
        while (R.Suiv!=p) R=R.Suiv;
        
        R.Suiv=T;
    }
    

    return L;

}

public Liste Suivant(Liste L) {
    return L.Suiv;
    
}
public Etudiant acces(Liste L , Liste p) {
    return p.info;
}
public boolean egale(Liste L1 , Liste L2){


    while(L1!=null && L2!=null){
    if (L1.info!= L2.info) {
        return false;
    }
    L1=L1.Suiv;
    L2=L2.Suiv;
}

    

    if(L1 == null && L2 ==null)
    return true;
    return false;
}

public boolean est_vide(Liste L) {
    if(L.info==null)return true;
    return false;
    
}
public Liste supprimer(Liste L , Liste p) {
    
    if(p==L) return L.Suiv;
    Liste Pt1=L ,Pt2=L.Suiv ;
    while (Pt2!=p) {
        Pt1=Pt1.Suiv;
        Pt2=Pt2.Suiv;
    }
    Pt1.Suiv=Pt2.Suiv;
    return L;
}



public Liste recherche(Liste L , Etudiant e){
    
    if(L.info==null)return new Liste();
    if(L.info.getNcarte()!=e.getNcarte()){
        return recherche(L.Suiv, e);
    }
    
        Liste R = new Liste();
        return inserer(R, R, L.info);
    
}

public void triBulle(Etudiant [] arr) {

    Etudiant c;
    for(int k =arr.length-1; k>1; k--)
    for (int i = 0; i < k; i++) {
        if (arr[i].getNom().compareTo(arr[i+1].getNom())<0) {
            c=arr[i];
            arr[i]=arr[i+1];
            arr[i+1]=c;
        }
    }

}

public Liste Tri(Liste L) {

    int n=0;
    Liste p=L;
    while(p.info!= null){
        n++;
        p=p.Suiv;
    }
    Etudiant arr []=new Etudiant[n];
    int i=0;
    while(L.info!=null){
        arr[i]=L.info;
        L=L.Suiv;
        i++;
    }
    triBulle(arr);
    Liste t=new Liste();
    for(Etudiant e : arr){
        t=inserer(t, t, e);
    }

return t;
}

public Liste inscription(Etudiant e) {
    if(e.getNom()==null)e.LireInfo();
    Liste L =inserer(this, this, e);
   return Tri(L);
}


public Liste transfert(Etudiant e) {
    return Tri(inserer(this, this, e));
    
}
public Liste exclusion(Etudiant e) {
    Liste L =recherche(this, e);
    if(est_vide(L)){ System.out.println(" le Etudiant ne exist pas dans la liste ");
    return this;
}
    else{
        return supprimer(this, L);
    }
}
public int  calcul() {
    Liste l = this;
    int i=0;
    while (l.info!=null) {
        if(!l.info.getAdresse().equals("constantine"))i++;
        l=l.Suiv;
    }
    return i;
}
}