/**
 * Liste
 */
public class Liste {

    private Element info;
    private Liste Suiv;



public static Liste liste_vide() {
    return new Liste();
}
public Liste inserer(Liste L , Liste p , Element e) {
    
    Liste T=new Liste();
    T.info = e;
    T.Suiv =p;
    if (p==L)
     L=T;
    else {
        Liste R =L;
        while (R.Suiv!=p) R=R.Suiv;
        
        R.Suiv=T;
    }
    

    return L;

}

public Liste Suivant(Liste L) {
    return L.Suiv;
    
}
public Element acces(Liste L , Liste p) {
    return p.info;
}
public boolean egale(Liste L1 , Liste L2){


    while(L1!=null && L2!=null){
    if (L1.info!= L2.info) {
        return false;
    }
    L1=L1.Suiv;
    L2=L2.Suiv;
}

    

    if(L1 == null && L2 ==null)
    return true;
    return false;
}

public boolean est_vide(Liste L) {
    if(L.info==null)return true;
    return false;
    
}

//! partie 2
public Liste recherche(Liste L , Element e){
    //todo later
    if(L.info==null)return new Liste();
    if(L.info.getId()!=e.getId()){
        return recherche(L.Suiv, e);
    }
    
        Liste R = new Liste();
        return inserer(R, R, L.info);
    
}

//! partie 3
public Liste difference(Liste L1 , Liste L2) {
    
        Liste T = new Liste();
    while(L1.info!=null){
        if(est_vide( recherche(L2, L1.info))){
            T=inserer(T, T, L1.info);
        }
        L1=L1.Suiv;
    }
    return T;
}





















}