
/**
 * List
 */
public class List {
 static final int LMAX=1000;
private Element tab[] = new Element[LMAX];
private int Longueur_list;

public static List listVide(){
    List L = new List();
    L.Longueur_list=0;
    return L;
}
public List inserer(List L , int p , Element e){



if (L.Longueur_list<LMAX) {
    if (L.Longueur_list !=0 && p!=L.Longueur_list+1) {
        for (int i = L.Longueur_list-1; i==p; i--) {
            L.tab[i+1]=L.tab[i];
        }

    }

    L.tab[p]=e;
    L.Longueur_list++;

} else {
    System.out.println(" insertion est impossible , la list est saturee ");
}
    return L;
}
 

public List supprimer(List L , int p){

    if(longueur_itr(L)!=1)
    for (int i = p; i < longueur_itr(L)-1; i++) {
        L.tab[i]=L.tab[i+1];
    }
    L.Longueur_list--;
    return L;


}

public Element acces(List L ,int p){return L.tab[p];}

public int longueur_itr(List L ){
    return L.Longueur_list;
}
public int Longueur_rec(List L){

    if(est_vide(L)) return 0;
    return 1+Longueur_rec(supprimer(L, 0));


}

public boolean est_vide(List L){
    return L.Longueur_list == 0;
}

// ! partie 2 :

public List inverse(List L){
    for (int i = 0; i < Longueur_list/2; i++) {
        Element c = L.tab[i];
        L.tab[i]=L.tab[Longueur_list- i-1];
        L.tab[Longueur_list-i-1]=c;
    }
    return L;
}

//! partie 3 : 

    public Element queue(List L) {
        return acces(L, Longueur_list-1);
    }




//! partie 4 : 
public List concatener(List L1 , List L2){

    while(!est_vide(L2)){
    
        L1 =inserer(L1,longueur_itr(L1) , acces(L2, 0));
        L2 =supprimer(L2, 0);
    }

    return L1;

}
}