import java.util.Scanner;

/**
 * Test
 */
public class Test {

    public static List creationList(List L) {
        Scanner sc = new Scanner(System.in);
        int n;
        do{
        System.out.println("Le nombre des Elements : ");
        n=sc.nextInt();
        }while(n>List.LMAX);
       
       for (int i = 0; i < n; i++) {
        System.out.println(" Element  nombre " + i + " : ");
        Element e = new Element(sc.nextInt()); 
        L=L.inserer(L, i, e);
        }
        
        return L;
    }
    
    public static void affichageList(List L) {
        

        for (int i = 0; i < L.longueur_itr(L); i++) {
            System.out.print( " " +  L.acces(L, i).getId() + " ");
        }

    }

    public static void main(String[] args) {
        
        List list1 = List.listVide();
        creationList(list1);
        
        if(list1.est_vide(list1)) System.out.println(" la list est vide ");
        else {System.out.println("les element de la list sont : ");
        affichageList(list1);}


        System.out.println(" \n partie 2 : ");
        if(list1.est_vide(list1)) System.out.println(" la list est vide ");
        else if(list1.longueur_itr(list1) == 1) affichageList(list1);
        else affichageList(list1.inverse(list1));


        System.out.println(" \n partie 3 : ");
        if(list1.est_vide(list1)) System.out.println(" la list est vide ");
        else if(list1.longueur_itr(list1) == 1) affichageList(list1);
        else System.out.println( " le dernier Element : " +list1.queue(list1).getId());
    
    
        System.out.println(" partie 4 : ");

        List list2 = List.listVide();
        creationList(list2);

        if(list1.est_vide(list1) && list2.est_vide(list2))System.out.println(" le resultat de la concatenation est une liste vide ");
        else if (list1.est_vide(list1) && !list2.est_vide(list2)) {
            System.out.println(" le resultat de la concatenation est :  ");
            affichageList(list2);
        }else if (!list1.est_vide(list1) && list2.est_vide(list2)) {
            System.out.println(" le resultat de la concatenation est :  ");
            affichageList(list1);
        }else if (list1.longueur_itr(list1) + list2.longueur_itr(list2) > List.LMAX){
            System.out.println(" la concatenation est impossible ");

        }else affichageList(list1.concatener(list1, list2));

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    }

}